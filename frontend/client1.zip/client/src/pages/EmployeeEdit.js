import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar'; 
import '../Styles/EmployeeEdit.css'; 

function EmployeeEdit() {
    const { id } = useParams();
    const navigate = useNavigate();
    const uuid = localStorage.getItem('uuid'); // Ensure UUID is stored in local storage

    const [formData, setFormData] = useState({
        name: '',
        email: '',
        mobileNO: '',
        designation: '',
        gender: '',
        courses: [], 
        image: null,
    });

    useEffect(() => {
        async function fetchEmployee() {
            if (!uuid) {
                console.error('UUID is missing');
                return;
            }

            try {
                const response = await axios.get(`http://localhost:8082/employe/${id}/${uuid}`);
                console.log('Fetched Data:', response.data); 
                setFormData({
                    ...response.data,
                    courses: response.data.courses.split(','), 
                });
            } catch (error) {
                console.error('Error fetching employee:', error);
            }
        }

        fetchEmployee();
    }, [id, uuid]);

    const handleChange = (e) => {
        const { name, value, type, checked, files } = e.target;
        if (type === 'checkbox') {
            setFormData(prevData => {
                const courses = prevData.courses;
                if (checked) {
                    return {
                        ...prevData,
                        courses: [...new Set([...courses, value])]
                    };
                } else {
                    return {
                        ...prevData,
                        courses: courses.filter(course => course !== value)
                    };
                }
            });
        } else if (type === 'file') {
            const file = files[0];
            if (file) {
                setFormData(prevData => ({
                    ...prevData,
                    image: file
                }));
            }
        } else {
            setFormData(prevData => ({
                ...prevData,
                [name]: value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const form = new FormData();
        form.append('name', formData.name);
        form.append('email', formData.email);
        form.append('mobileNO', formData.mobileNO);
        form.append('designation', formData.designation);
        form.append('gender', formData.gender);
        form.append('courses', formData.courses.join(',')); 
        if (formData.image) {
            form.append('image', formData.image);
        }

        try {
            const response = await axios.put(`http://localhost:8082/employe/updatebyid/${id}/${uuid}`, form, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            if (response.status === 200) {
                alert('Employee updated successfully');
                navigate('/employeeList');
            }
        } catch (error) {
            console.error('Error updating employee:', error);
        }
    };

    return (
        <div className="employee-edit">
            <Navbar userName="User Name" /> {/* Replace "User Name" with actual user name */}
            <h1>Edit Employee</h1>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Name</label>
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Mobile No</label>
                    <input
                        type="text"
                        name="mobileNO"
                        value={formData.mobileNO}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Designation</label>
                    <select
                        name="designation"
                        value={formData.designation}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select</option>
                        <option value="HR">HR</option>
                        <option value="Manager">Manager</option>
                        <option value="Sales">Sales</option>
                    </select>
                </div>
                <div>
                    <label>Gender</label>
                    <div className="gender-options">
                        <label>
                            <input
                                type="radio"
                                name="gender"
                                value="M"
                                checked={formData.gender === 'M'}
                                onChange={handleChange}
                            />
                            Male
                        </label>
                        <label>
                            <input
                                type="radio"
                                name="gender"
                                value="F"
                                checked={formData.gender === 'F'}
                                onChange={handleChange}
                            />
                            Female
                        </label>
                    </div>
                </div>
                <div>
                    <label>Courses</label>
                    <div className="course-options">
                        <label>
                            <input
                                type="checkbox"
                                name="courses"
                                value="MCA"
                                checked={formData.courses.includes('MCA')}
                                onChange={handleChange}
                            />
                            MCA
                        </label>
                        <label>
                            <input
                                type="checkbox"
                                name="courses"
                                value="BCA"
                                checked={formData.courses.includes('BCA')}
                                onChange={handleChange}
                            />
                            BCA
                        </label>
                        <label>
                            <input
                                type="checkbox"
                                name="courses"
                                value="BSC"
                                checked={formData.courses.includes('BSC')}
                                onChange={handleChange}
                            />
                            BSC
                        </label>
                    </div>
                </div>
                <div className="form-group">
                    <label>Image Upload</label>
                    <input
                        type="file"
                        name="image"
                        onChange={handleChange}
                        accept=".jpg,.png"
                    />
                </div>
                <button type="submit">Update</button>
            </form>
        </div>
    );
}

export default EmployeeEdit;
