import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import '../Styles/EmployeeForm.css';

function EmployeeForm() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        mobileNO: '',
        designation: '',
        gender: '',
        courses: [],
        image: null,
    });

    const uuid = localStorage.getItem('uuid');
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value, type, checked, files } = e.target;
        if (type === 'checkbox') {
            setFormData(prevData => ({
                ...prevData,
                courses: checked 
                    ? [...prevData.courses, value] 
                    : prevData.courses.filter(course => course !== value)
            }));
        } else if (type === 'file') {
            const file = files[0];
            if (file) {
                setFormData(prevData => ({
                    ...prevData,
                    image: file
                }));
            }
        } else {
            setFormData(prevData => ({
                ...prevData,
                [name]: value
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        const form = new FormData();
        form.append('name', formData.name);
        form.append('email', formData.email);
        form.append('mobileNO', formData.mobileNO);
        form.append('designation', formData.designation);
        form.append('gender', formData.gender);
        form.append('courses', formData.courses.join(',')); 
        if (formData.image) {
            form.append('image', formData.image);
        }

        try {
             await axios.post(`http://localhost:8082/employe/create/${uuid}`, form, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                }
            });
            alert('Employee added successfully');
            navigate('/employeeList');
        } catch (error) {
            console.error('Error:', error.response ? error.response.data : error.message);
            alert('An error occurred while adding the employee.');
        }
    };

    return (
        <>
            <Navbar userName="User Name" />
            <div className="employee-form">
                <h1>Add Employee</h1>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Name</label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Email</label>
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Mobile No</label>
                        <input
                            type="text"
                            name="mobileNO"
                            value={formData.mobileNO} 
                            onChange={handleChange}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Designation</label>
                        <select
                            name="designation"
                            value={formData.designation}
                            onChange={handleChange}
                            required
                        >
                            <option value="">Select</option>
                            <option value="HR">HR</option>
                            <option value="Manager">Manager</option>
                            <option value="Sales">Sales</option>
                        </select>
                    </div>
                    <div>
                        <label>Gender</label>
                        <div className="gender-options">
                            <label>
                                <input
                                    type="radio"
                                    name="gender"
                                    value="M"
                                    checked={formData.gender === 'M'}
                                    onChange={handleChange}
                                />
                                Male
                            </label>
                            <label>
                                <input
                                    type="radio"
                                    name="gender"
                                    value="F"
                                    checked={formData.gender === 'F'}
                                    onChange={handleChange}
                                />
                                Female
                            </label>
                        </div>
                    </div>
                    <div>
                        <label>Courses</label>
                        <div className="course-options">
                            <label>
                                <input
                                    type="checkbox"
                                    name="courses"
                                    value="MCA"
                                    checked={formData.courses.includes('MCA')}
                                    onChange={handleChange}
                                />
                                MCA
                            </label>
                            <label>
                                <input
                                    type="checkbox"
                                    name="courses"
                                    value="BCA"
                                    checked={formData.courses.includes('BCA')}
                                    onChange={handleChange}
                                />
                                BCA
                            </label>
                            <label>
                                <input
                                    type="checkbox"
                                    name="courses"
                                    value="BSC"
                                    checked={formData.courses.includes('BSC')}
                                    onChange={handleChange}
                                />
                                BSC
                            </label>
                        </div>
                    </div>
                    <div className="form-group">
                        <label>Image Upload</label>
                        <input
                            type="file"
                            name="image"
                            onChange={handleChange}
                            accept=".jpg,.png"
                        />
                    </div>
                    <button type="submit">Submit</button>
                </form>
            </div>
        </>
    );
}

export default EmployeeForm;
