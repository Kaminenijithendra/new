import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import '../Styles/Navbar.css'; 

const Navbar = () => {
    const navigate = useNavigate();
    const userName = localStorage.getItem('username');
    const uuid = localStorage.getItem('uuid'); // Fetch UUID from localStorage

    const handleLogout = async () => {
        try {
            if (uuid) {
                // Send logout request to the backend
                await axios.delete(`http://localhost:8082/admin/logOut/${uuid}`);
            }

            // Clear local storage
            localStorage.removeItem('token'); 
            localStorage.removeItem('username'); 
            localStorage.removeItem('uuid'); 

            // Navigate to the login page
            navigate('/');
        } catch (error) {
            console.error('Error during logout:', error);
        }
    };

    return (
        <nav className="navbar">
            <div className="navbar-items">
                <Link to="/Home">Home</Link>
                <Link to="/employeeList">Employee List</Link>
                {userName && <span className="user-name">Welcome, {userName}</span>}
                
                <button onClick={handleLogout} className="logout-button">Logout</button>
            </div>
        </nav>
    );
};

export default Navbar;
